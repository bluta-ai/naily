WOOTING 80HE × CHATGPT / CLAUDE — Chrome-only v0.9.3
======================================================

本版本重點：修正 Claude.ai 狀態偵測，而不改動已經成功的 RGB 通訊。

更新方法（保留現有 Chrome 鍵盤授權）：
1. 關閉 ChatGPT / Claude 擴充功能的小視窗。
2. 解壓本 ZIP，把新的 extension 資料夾中的所有檔案複製並覆蓋你原本 Chrome 正在使用的 extension 資料夾。
   注意：不要只把 ZIP 解壓到 Downloads；必須覆蓋已在 Chrome 載入的「同一個」extension 資料夾。
3. 在 chrome://extensions 找到 Wooting 80HE · AI Full Keyboard RGB，按「重新載入」。
4. 在 Claude.ai 與 ChatGPT 的每個分頁按 Ctrl+R。
5. 開啟 https://claude.ai/ ，進入聊天分頁，打開擴充功能。
6. 在「頁面監測器」確認顯示已啟動，然後從 Claude 發送一條較長的訊息。

預期燈效：
- 發送問題／生成回答：整鍵盤藍色呼吸。
- 回答完成：綠色亮／暗持續閃爍，直到按鍵或在 ChatGPT／Claude 網頁點擊滑鼠。
- 同意／授權提示：紅色雙閃（僅限可從網頁辨識的對話框）。
- 按鍵／滑鼠確認：還原正常 Wootility RGB。
- 正常回答即使最後以問題結尾，也一律當作完成（綠色），不會誤判成橙色。

Claude.ai 特別修正：
- 使用 Claude 的 data-is-streaming 屬性偵測生成中，即使找不到 Stop 按鈕也能運作。
- 支援 Claude 的 ProseMirror 文字輸入、fieldset 發送按鈕，並監察 Claude 回覆節點變化。
- 如果 Claude 版本沒有串流屬性或 Stop 按鈕，改用回覆節點停止變動作後備判斷（較保守，可能會較慢）。
- 切換 Claude 對話時清除舊會話訊號。

如果仍然不偵測 Claude：
1. 確認使用的是 https://claude.ai（不是 Windows Claude Desktop App）。
2. 在 Claude 分頁打開擴充功能，查看「頁面監測器已啟動」。
3. Claude 生成時，診斷欄應顯示「Claude streaming true」（如果網站有該標記）或「停止／串流 ✓」。
4. 按「複製診斷狀態」，把 JSON 提供給 ChatGPT 分析。診斷內容不包含對話文字。
5. 如果擴充功能表示「網頁監測器未載入」，請再次在 Claude 分頁 Ctrl+R，並檢查 Chrome 擴充功能對 claude.ai 的網站存取權限。

測試：
- tests/test_claude.js：Claude 開始、停止、缺少 Stop 按鈕、切換對話。
- tests/test_content.js：ChatGPT 基本行為。
- tests/test_background.js / test_analog_ack.js / test_protocol.js：WebHID、RGB、按鍵確認、資料包。
- 所有測試為本機模擬，尚未在你的實體 Claude 分頁上驗證。

不需要 Python、DLL 或 API Key。此擴充功能只讀取 UI 結構和狀態，不上傳聊天文字。
