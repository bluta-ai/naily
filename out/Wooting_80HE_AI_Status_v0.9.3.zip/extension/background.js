'use strict';
importScripts('protocol.js');

const sessions = new Map(); // only: tab ID, state, time, hostname.
let device = null;
let analogDevice = null;
let analogConnecting = null;
let analogWasDown = false;
let analogFrames = 0;
let analogLastFrameAt = 0;
let analogError = '';
let lastAcknowledgedAt = 0;
let connecting = null;
let interval = null;
let mode = 'idle';
let lastColor = '';
let lastError = '';
let initializedRgb = false;
let writing = false;
let sendFault = false;
let test = null;
let enabled = true;
let brightness = 60;
let lastWriteAt = 0;
let firstStart = true;
let lastPageMessageAt = 0;
let lastReportLength = null;

function asError(e) { return String(e?.message || e || 'unknown error').slice(0, 350); }
function deviceLabel(d) { return d ? `${d.productName || 'Wooting 80HE'} · PID 0x${d.productId.toString(16).toUpperCase()}` : ''; }
function liveSessions(now = Date.now()) {
  const modes = [];
  for (const [id, s] of sessions) {
    // Completed answers remain latched until a Wooting keypress or a click/key in an AI page.
    // Only stale/transient states expire when a tab stops reporting.
    if (now - s.at > 35000 && s.state !== 'done') { sessions.delete(id); continue; }
    if (s.state !== 'idle') modes.push(s.state);
  }
  return modes;
}
function getMode(now = Date.now()) {
  if (test && now < test.until) return test.state;
  if (test && now >= test.until) test = null;
  return priorityState(liveSessions(now));
}
function sourceAllowed(sender) {
  if (!Number.isInteger(sender?.tab?.id)) return false;
  try {return ['chatgpt.com','chat.openai.com','claude.ai'].includes(new URL(sender.url).hostname);}
  catch {return false;}
}
async function acknowledgeAnswers(reason) {
  const ids=[];
  for (const [id,s] of sessions) {
    // Only completed answers are acknowledged; amber stays until the question is answered.
    if (s.state !== 'done') continue;
    sessions.set(id,{...s,state:'idle',at:Date.now(),reason});
    ids.push(id);
  }
  const clearedTest=!!(test && ['done','needs_input'].includes(test.state));
  if (clearedTest) test=null;
  if (!ids.length && !clearedTest) return;
  lastAcknowledgedAt=Date.now();
  // Let the AI webpage watcher clear its local latch, or its next heartbeat
  // would otherwise turn the keyboard green again after acknowledgement.
  for (const id of ids) {
    chrome.tabs.sendMessage(id,{type:'WOOTING_ACKNOWLEDGED',reason}).catch(()=>{});
  }
  await update();
}
function onAnalogInput(e) {
  if (!analogDevice || e.device !== analogDevice || !e.data) return;
  analogFrames++;
  const pressed=analogReportHasPressedKey(e.data,isAnalogV2(analogDevice));
  const now=Date.now();
  // A new downstroke, not a repeated report for a held-down key.
  // Protect against stale last-key state if input reports stopped unexpectedly.
  const wasDown=analogWasDown && now-analogLastFrameAt < 1200;
  analogLastFrameAt=now;
  analogWasDown=pressed;
  if (pressed && !wasDown) {
    acknowledgeAnswers('wooting_physical_key').catch(err=>{analogError=asError(err);});
  }
}
async function connectAnalogSaved() {
  if (analogConnecting) return analogConnecting;
  analogConnecting=(async()=>{
    if (!navigator.hid) return false;
    const all=await navigator.hid.getDevices();
    const found=all.find(isAnalogDevice);
    if (!found) {analogError='Analog key HID (FF53) not authorised; enable in Connect / Diagnose for global key acknowledgement.';return false;}
    if (analogDevice && analogDevice!==found) {
      analogDevice.removeEventListener('inputreport',onAnalogInput);
      if (analogDevice.opened) await analogDevice.close().catch(()=>{});
    }
    analogDevice=found;
    if (!analogDevice.opened) await analogDevice.open();
    analogDevice.removeEventListener('inputreport',onAnalogInput);
    analogDevice.addEventListener('inputreport',onAnalogInput);
    analogError='';analogWasDown=false;analogFrames=0;analogLastFrameAt=0;
    return true;
  })().catch(e=>{analogError=`Analog HID connection failed: ${asError(e)}`;return false;})
    .finally(()=>{analogConnecting=null;});
  return analogConnecting;
}
async function setBadge(state) {
  const spec = {
    permission: ['!!', '#E44450'], needs_input: ['!', '#ECA63A'],
    working: ['…', '#287CDD'], done: ['✓', '#238D65'], idle: ['', '#343D4A']
  }[state];
  await Promise.allSettled([
    chrome.action.setBadgeText({text:spec[0]}),
    chrome.action.setBadgeBackgroundColor({color:spec[1]})
  ]);
}
async function resetRgb() {
  if (!device?.opened) return;
  // This is an SDK reset-all-LIVE-RGB command, not a profile save or keyboard reset.
  try {
    await device.sendFeatureReport(WOOTING_FEATURE_REPORT_ID, makeFeatureCommand(WOOTING_RGB_RESET));
    initializedRgb = false;
    lastColor = '';
    sendFault = false;
    lastError = '';
  } catch(e) { lastError = `Restore RGB failed: ${asError(e)}`; }
}
async function sendRgb(state, now) {
  if (!device?.opened || !enabled || sendFault) return;
  if (state === 'idle') {
    if (initializedRgb) await resetRgb();
    return;
  }
  const rgb = frameForState(state, now, brightness / 100);
  if (!rgb) return;
  const colorId = rgb.join(',');
  // Keep the volatile RGB override refreshed periodically. Some device/
  // firmware combinations fall back to the onboard Wootility animation if
  // WebHID writes stop while a static flash phase is being displayed.
  if (colorId === lastColor && now - lastWriteAt < 500) return;
  try {
    if (!initializedRgb) {
      await device.sendFeatureReport(WOOTING_FEATURE_REPORT_ID, makeFeatureCommand(WOOTING_RGB_INIT));
      initializedRgb = true;
    }
    const reportLength = findRgbReportLength(device);
    lastReportLength = reportLength;
    await device.sendReport(WOOTING_RGB_REPORT_ID, makeRgbReport(...rgb, reportLength));
    lastColor = colorId;
    lastWriteAt = Date.now();
    lastError = '';
  } catch(e) {
    sendFault = true;
    device.sendFeatureReport(WOOTING_FEATURE_REPORT_ID, makeFeatureCommand(WOOTING_RGB_RESET)).catch(()=>{});
    initializedRgb = false;
    lastError = `80HE whole-keyboard RGB write failed: ${asError(e)} (report 5, length ${lastReportLength || 'unknown'})`;
    // Stop spamming HID if firmware or Chrome rejects a report.
  }
}
async function update() {
  const next = getMode();
  if (mode !== next) { mode = next; setBadge(mode); }
  if (writing) return;
  if (!device?.opened || !enabled) return;
  writing = true;
  try { await sendRgb(mode, Date.now()); }
  finally { writing = false; }
}
function ensureTick() {
  if (interval != null) return;
  interval = setInterval(() => { update().catch(e => { lastError = asError(e); }); }, 220);
}
function stopTick() {
  if (interval != null) { clearInterval(interval); interval = null; }
}
async function connectSaved() {
  if (connecting) return connecting;
  connecting = (async()=>{
    if (!navigator.hid) throw new Error('Chrome WebHID unavailable');
    const all = await navigator.hid.getDevices();
    const found = all.find(isConfigDevice);
    if (!found) {
      lastError = all.some(is80he) ? '80HE granted, but the FF55 RGB config HID interface is not authorised.' : '80HE not authorised. Open Connect keyboard.';
      return false;
    }
    if (device && device !== found && device.opened) await device.close().catch(()=>{});
    device = found;
    if (!device.opened) await device.open();
    // A previous service-worker instance may have left the keyboard in live-RGB
    // mode (e.g. on a dim flash frame) when the extension was reloaded or
    // suspended. Always hand the lighting back to the onboard profile on connect;
    // update() below re-takes control only if a status colour is needed.
    await device.sendFeatureReport(WOOTING_FEATURE_REPORT_ID, makeFeatureCommand(WOOTING_RGB_RESET)).catch(()=>{});
    sendFault = false;
    lastColor = '';
    initializedRgb = false;
    lastError = '';
    ensureTick();
    await update();
    return true;
  })().catch(e=>{ device=null; lastError=`HID access failed: ${asError(e)}`; return false; })
    .finally(()=>{connecting=null;});
  return connecting;
}
async function readSettings() {
  const s = await chrome.storage.local.get(['enabled', 'brightness']);
  enabled = s.enabled !== false;
  brightness = Number.isFinite(s.brightness) ? Math.max(20,Math.min(100,Math.round(s.brightness))) : 60;
}
async function getStatus() {
  return {
    connected: !!device?.opened, deviceName:deviceLabel(device), state:mode,
    enabled, brightness, detectQuestions:false, error:lastError, reportLength:lastReportLength,
    activeTabs:liveSessions().length, observedTabs:sessions.size, lastPageMessageAt,
    testActive:!!(test && Date.now()<test.until),
    globalKeyConnected:!!analogDevice?.opened, analogFrames, analogError, lastAcknowledgedAt,
    rgbActive:initializedRgb, lastWriteAt, protocol:'Wooting official raw RGB (WebHID)'
  };
}
const started = (async()=>{
  await readSettings();
  await connectSaved();
  await connectAnalogSaved();
  await setBadge(mode);
  firstStart = false;
})();
chrome.runtime.onStartup.addListener(()=>started.catch(()=>{}));
chrome.runtime.onInstalled.addListener(()=>started.catch(()=>{}));
chrome.alarms.create('wooting-reconnect', {periodInMinutes:1});
chrome.alarms.onAlarm.addListener(a=>{
  if (a.name === 'wooting-reconnect') {
    (async()=>{if (!device?.opened) await connectSaved(); if (!analogDevice?.opened) await connectAnalogSaved(); await update();})().catch(()=>{});
  }
});
chrome.tabs.onRemoved.addListener(id=>{sessions.delete(id);update().catch(()=>{});});
// A conversation tab can navigate away without closing. Do not keep a green
// acknowledgement alert for a page that is no longer displaying that answer.
chrome.tabs.onUpdated.addListener((id,changeInfo)=>{
  if (typeof changeInfo.url === 'string') {
    sessions.delete(id);
    update().catch(()=>{});
  }
});
if (navigator.hid) {
  navigator.hid.addEventListener('disconnect', e=>{
    if (device && e.device.productId === device.productId) {
      device=null; initializedRgb=false; lastColor='';
      lastError='Wooting disconnected. Reconnect USB and open Connect keyboard.';
      stopTick();
    }
    if (analogDevice && e.device.productId === analogDevice.productId && e.device===analogDevice) {
      analogDevice=null;analogWasDown=false;
      analogError='Analog keyboard HID disconnected.';
    }
  });
  navigator.hid.addEventListener('connect', ()=>{connectSaved().catch(()=>{}); connectAnalogSaved().catch(()=>{});});
}
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  (async()=>{
    await started;
    if (msg?.type === 'ACK_KEY' || msg?.type === 'ACK_MOUSE') {
      if (!sourceAllowed(sender)) return {ok:false};
      await acknowledgeAnswers(msg.type==='ACK_MOUSE' ? 'ai_page_mouse_click' : 'ai_page_keypress');
      return {ok:true};
    }
    if (msg?.type === 'CONNECT_ANALOG') {
      const ok=await connectAnalogSaved();
      return {...await getStatus(),ok};
    }
    if (msg?.type === 'AI_STATUS') {
      if (!sender.tab || !Number.isInteger(sender.tab.id)) return {ok:false};
      let url;
      try { url=new URL(sender.url || 'https://invalid.example'); }
      catch { return {ok:false}; }
      if (!['chatgpt.com','chat.openai.com','claude.ai'].includes(url.hostname) || !VALID_STATES.includes(msg.state)) return {ok:false};
      const at = Date.now();
      // An old content script may still send needs_input until its tab is refreshed.
      // Normalize legacy amber to green: it must not override new completed answers.
      // v0.9.2+: amber is allowed only for a detected Claude question card.
      const effectiveState = msg.state === 'needs_input' && msg.reason !== 'claude_question_card' ? 'done' : msg.state;
      sessions.set(sender.tab.id,{state:effectiveState,at,site:url.hostname,
        reason:typeof msg.reason==='string'?msg.reason.slice(0,60):'',
        telemetry:typeof msg.telemetry==='object' && msg.telemetry ? {
          watcherVersion:String(msg.telemetry.watcherVersion||'').slice(0,16),
          composerPresent:!!msg.telemetry.composerPresent,
          sendControl:!!msg.telemetry.sendControl,
          busyControl:!!msg.telemetry.busyControl,
          activeRequest:!!msg.telemetry.activeRequest,
          assistantMarkers:Number(msg.telemetry.assistantMarkers)||0,
          claudeStreaming:msg.telemetry.claudeStreaming === null ? null : !!msg.telemetry.claudeStreaming,
          claudeStreamingSeen:!!msg.telemetry.claudeStreamingSeen,
          lastDetectedSignal:String(msg.telemetry.lastDetectedSignal||'').slice(0,40),
          lastSendReason:String(msg.telemetry.lastSendReason||'').slice(0,40),
          sendErrors:Number(msg.telemetry.sendErrors)||0
        } : null});
      lastPageMessageAt=at;
      await update();
      return {ok:true};
    }
    if (msg?.type === 'GET_STATUS') {
      if (!device?.opened) await connectSaved();
      if (!analogDevice?.opened && !analogConnecting) await connectAnalogSaved();
      await update();
      const status=await getStatus();
      if (Number.isInteger(msg.tabId)) status.monitor=sessions.get(msg.tabId)||null;
      return status;
    }
    if (msg?.type === 'CONNECT_HID') {
      const ok=await connectSaved();
      return {...await getStatus(),ok};
    }
    if (msg?.type === 'TEST_RGB') {
      if (!VALID_STATES.includes(msg.state) || msg.state==='idle') return {ok:false,error:'Invalid test state'};
      if (!device?.opened) await connectSaved();
      test={state:msg.state,until:Date.now()+9000};
      // Allow an explicit test to retry an earlier failed HID write.
      sendFault=false;lastColor='';
      await update();
      return {...await getStatus(),ok:!!device?.opened && !sendFault};
    }
    if (msg?.type === 'CLEAR_TEST') {
      test=null;
      // Restore immediately, regardless of other active sessions; they can resume on next heartbeat.
      sessions.clear(); mode='idle'; await setBadge(mode);
      await resetRgb();
      return {...await getStatus(),ok:true};
    }
    if (msg?.type === 'SAVE_SETTINGS') {
      if (!Number.isFinite(msg.brightness) || msg.brightness<20 || msg.brightness>100)
        return {ok:false,error:'Brightness must be 20..100'};
      brightness=Math.round(msg.brightness);
      enabled=msg.enabled!==false;
      // Retire the old question-to-amber option, including previously saved values.
      await chrome.storage.local.set({enabled,brightness,detectQuestions:false});
      lastColor='';sendFault=false;
      if (!enabled) {await resetRgb(); stopTick();}
      else {if (!device?.opened) await connectSaved();ensureTick();await update();}
      return {...await getStatus(),ok:true};
    }
    return {ok:false};
  })().then(respond).catch(e=>respond({ok:false,error:asError(e)}));
  return true;
});
