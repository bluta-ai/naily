// ChatGPT / Claude webpage status detection.
// Detect AI activity without inspecting the content of replies.
// A normal completed answer ALWAYS produces a green alert until acknowledgement.
(() => {
  'use strict';
  if (globalThis.__wootingAiStatusObserverV10) return;
  globalThis.__wootingAiStatusObserverV10 = true;
  const isChatGPT = /^(chatgpt\.com|chat\.openai\.com)$/.test(location.hostname);
  const site = isChatGPT ? 'ChatGPT' : 'Claude';
  const isClaude = !isChatGPT;
  const STOP_GLYPH = 'M4.5 5.75C4.5 5.05964 5.05964 4.5 5.75 4.5H14.25C14.9404 4.5 15.5 5.05964 15.5 5.75V14.25C15.5 14.9404 14.9404 15.5 14.25 15.5H5.75C5.05964 15.5 4.5 14.9404 4.5 14.25V5.75Z';
  // ChatGPT uses different controls between composer versions. Some display a square SVG Stop glyph.
  const STOP_SELECTORS = [
    'button[data-testid="stop-button"]', 'button[data-testid="code-prompt-stop"]', '[data-testid="stop-generating-button"]',
    'button[aria-label="Stop generating"]', 'button[aria-label="Stop response"]',
    'button[aria-label="Stop"]', 'button[title="Stop generating"]',
    'button[title="Stop response"]', 'button[data-testid*="stop-generat"]',
    'button[aria-label*="Stop response" i]', 'button[aria-label*="Stop generating" i]',
    'button[data-testid*="stop" i]', 'button[title*="Stop" i]',
    `form[data-chatgpt-composer] button:has(svg.icon-primary-action > path[d="${STOP_GLYPH}"])`,
  ];
  const SEND_SELECTORS = [
    '#composer-submit-button', 'button[data-testid="code-prompt-send"]', 'button[data-testid="send-button"]',
    'button[data-testid="composer-send-button"]',
    'button[aria-label="Send message"]', 'button[aria-label="Send prompt"]',
    'button[aria-label="Send Message"]', 'button[title="Send message"]',
    'button[aria-label*="Send" i]', 'button[title*="Send" i]',
    'button[data-testid*="send" i]',
    'button[type="submit"]',
  ];
  const COMPOSER_SELECTORS = [
    '#prompt-textarea', 'textarea[name="prompt-textarea"]',
    'textarea#mobile-composer-prompt', '[contenteditable="true"][data-placeholder]',
    '[contenteditable="true"][role="textbox"]',
    '[contenteditable="true"].ProseMirror',
    '[data-testid="chat-input"] [contenteditable="true"]',
    'div.ProseMirror[contenteditable="true"]',
    'fieldset [contenteditable="true"]',
    '[contenteditable="true"][aria-label]',
    '[contenteditable="true"][translate="no"]',
  ];
  const ASSISTANT_SELECTOR = isChatGPT
    ? '[data-message-author-role="assistant"]'
    : '[data-testid="assistant-message"], [data-role="assistant"], [data-testid="message"] [data-testid="assistant"], .font-claude-message, .font-claude-response, [data-is-streaming]';
  const APPROVE = /^(allow|approve|confirm|continue|authorize|grant access|proceed|connect|允許|批准|确认|確認|繼續|继续)$/i;
  const SEND_RE = /^(send( message| prompt)?|發送|发送|送出)$/i;
  const STOP_RE = /^(stop( generating| response)?|停止(生成|回覆|回复)?|中止(生成|回覆|回复)?)$/i;

  let state = null;
  let lastSentAt = 0;
  let lastReason = 'watcher_loaded';
  let startedAt = 0;
  let busySeen = false;
  let lastBusyAt = 0;
  let assistantBaseline = 0;
  let lastAssistantChangeAt = 0;
  let lastAssistantCount = 0;
  let completedAt = 0;
  let acknowledgeAfter = 0;
  let scanTimer = null;
  let demo = false;
  let demoTimer = [];
  let sendErrors = 0;
  let previousBusy = false;
  let lastClaudeStream = null;
  let sawClaudeStream = false;
  let lastLocation = location.href;
  let lastScanAt = 0;
  let lastSendReason = '';
  let lastDetectedSignal = 'none';

  function visible(el) {
    if (!el || !el.isConnected || el.disabled || el.getClientRects().length === 0) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  }
  function queryVisible(selectors) {
    return selectors.some(s => {
      try { return Array.from(document.querySelectorAll(s)).some(visible); }
      catch (_) { return false; }
    });
  }
  function composer() {
    for (const s of COMPOSER_SELECTORS) {
      const el = document.querySelector(s);
      if (el && visible(el)) return el;
    }
    return null;
  }
  // Find the container holding the composer's buttons. Claude does not always wrap
  // its composer in a <form> or <fieldset>, so walk up a few levels as a fallback.
  function composerControls(input) {
    if (!input) return isChatGPT ? document.querySelector('form[data-chatgpt-composer]') : null;
    const direct = input.closest('form') || input.closest('fieldset');
    if (direct) return direct;
    let el = input.parentElement;
    for (let i = 0; el && i < 8; i++, el = el.parentElement) {
      try { if (el.querySelectorAll('button').length >= 2) return el; } catch (_) { return null; }
    }
    return null;
  }
  function buttonLabel(b) {
    return (b.getAttribute('aria-label') || b.getAttribute('title') || '').trim();
  }
  // Diagnostic only: labels of the composer's buttons (UI labels, never chat text).
  function composerButtonLabels() {
    const controls = composerControls(composer());
    if (!controls) return [];
    try {
      return Array.from(controls.querySelectorAll('button')).filter(visible)
        .map(b => buttonLabel(b).slice(0, 40) || '(unlabelled)').slice(0, 12);
    } catch (_) { return []; }
  }
  // Claude exposes the streaming attribute on its response nodes in some web builds.
  // Only the current (last) response matters; old completed messages may retain
  // data-is-streaming="false". We inspect attributes, never conversation text.
  function claudeStreaming() {
    if (!isClaude) return null;
    const nodes = Array.from(document.querySelectorAll('[data-is-streaming]'));
    if (!nodes.length) return null;
    const latest = nodes[nodes.length - 1];
    return latest.getAttribute('data-is-streaming') === 'true';
  }
  function busy() {
    if (isClaude && claudeStreaming() === true) {lastDetectedSignal='claude_stream_attribute';return true;}
    if (queryVisible(STOP_SELECTORS)) {lastDetectedSignal='stop_button';return true;}
    // Fallback for localized UI labels; scope to composer rather than arbitrary chat text.
    const controls = composerControls(composer());
    if (!controls) return false;
    const stop = Array.from(controls.querySelectorAll('button')).some(b => visible(b) &&
      STOP_RE.test(buttonLabel(b)));
    if (stop) lastDetectedSignal='composer_stop_button';
    return stop;
  }
  function hasPermissionPrompt() {
    return Array.from(document.querySelectorAll('[role="alertdialog"], [role="dialog"], dialog[open]')).some(d =>
      visible(d) && Array.from(d.querySelectorAll('button')).some(b =>
        visible(b) && APPROVE.test((b.innerText || b.getAttribute('aria-label') || '').trim())));
  }
  // Claude Code on the web (claude.ai/code) shows questions from Claude as an inline
  // card (role=group) with "Skip" and "Submit" buttons while the Stop button stays
  // visible. Only button labels are matched; nothing is read from or sent about the chat.
  function btnText(b) {
    return (b.getAttribute('aria-label') || b.innerText || b.textContent || '').trim();
  }
  function questionCardOpen() {
    if (!isClaude) return false;
    try {
      for (const g of document.querySelectorAll('[role="group"]')) {
        if (!visible(g)) continue;
        const labels = Array.from(g.querySelectorAll('button')).filter(visible).map(btnText);
        if (labels.some(l => /^skip$/i.test(l)) && labels.some(l => /^submit/i.test(l))) return true;
      }
      return Array.from(document.querySelectorAll('button')).some(b =>
        visible(b) && /^needs your input/i.test(btnText(b)));
    } catch (_) { return false; }
  }
  function assistantCount() {
    try { return document.querySelectorAll(ASSISTANT_SELECTOR).length; }
    catch (_) { return 0; }
  }
  function snapshot() {
    return {
      site, busyControl: busy(), composerPresent: !!composer(),
      sendControl: queryVisible(SEND_SELECTORS), assistantMarkers: assistantCount(),
      questionCard: questionCardOpen(),
      claudeStreaming: claudeStreaming(), claudeStreamingSeen: sawClaudeStream,
      lastDetectedSignal, lastSendReason, lastScanAgeMs: Date.now() - lastScanAt,
      activeRequest: !!startedAt,
      streamingNodes: (() => { try { return document.querySelectorAll('[data-is-streaming]').length; } catch (_) { return 0; } })(),
      composerButtons: composerButtonLabels(),
      lastReason, watcherVersion: '0.9.3', sendErrors,
    };
  }
  function publish(next, reason, force = false) {
    if (demo && reason !== 'demo') return;
    const now = Date.now();
    if (!force && next === state && now - lastSentAt < 4500) return;
    state = next;
    lastSentAt = now;
    lastReason = reason;
    try {
      chrome.runtime.sendMessage({type: 'AI_STATUS', state: next, reason,
        telemetry: snapshot()}).then(r => { if (!r?.ok) sendErrors++; }).catch(() => { sendErrors++; });
    } catch (_) { sendErrors++; }
  }
  function submit(reason) {
    if (demo) return;
    const now = Date.now();
    if (startedAt && now - startedAt < 800) return; // Prevent duplicate click/submit/keydown.
    startedAt = now;
    lastSendReason = reason;
    busySeen = false;
    lastBusyAt = 0;
    lastAssistantChangeAt = 0;
    assistantBaseline = assistantCount();
    lastAssistantCount = assistantBaseline;
    completedAt = 0;
    publish('working', reason, true);
    queueScan();
  }
  function done(reason) {
    startedAt = 0;
    // Completion is never reclassified as "needs input" by answer wording.
    completedAt = Date.now();
    acknowledgeAfter = completedAt;
    publish('done', reason, true);
  }
  function acknowledge(reason) {
    if (state !== 'done' || Date.now() < acknowledgeAfter) return;
    completedAt = 0;
    if (demo) {for (const t of demoTimer) clearTimeout(t); demoTimer=[];demo=false;}
    publish('idle', reason, true);
  }
  function scan() {
    if (demo) return;
    const now = Date.now();
    lastScanAt = now;
    // Claude uses SPA navigation. Do not carry an old conversation's green latch
    // into a newly opened chat when the route changes without a page reload.
    if (location.href !== lastLocation) {
      lastLocation=location.href;
      if (startedAt && !completedAt) {
        // A request is in flight (e.g. claude.ai/new -> /chat/<id> after the first
        // message). Keep tracking it; just re-register the tab with the service worker,
        // which dropped its session entry on the URL change.
        publish('working', 'conversation_url_updated', true);
      } else {
      startedAt=0; busySeen=false; lastBusyAt=0; completedAt=0; previousBusy=false;
      lastAssistantChangeAt=0; lastClaudeStream=null; sawClaudeStream=false;
      publish('idle','conversation_changed',true);
      }
    }
    const signal = claudeStreaming();
    if (isClaude && signal === true) sawClaudeStream=true;
    lastClaudeStream = signal;
    const isBusy = busy();
    const count = assistantCount();
    if (hasPermissionPrompt()) {
      publish('permission', 'approval_dialog');
      return;
    }
    if (questionCardOpen()) {
      // Amber while Claude waits for an answer. Keep the request tracked so that
      // after the question is answered the Stop button turns it blue again.
      if (!startedAt) { startedAt = now; assistantBaseline = count; }
      busySeen = true; lastBusyAt = now;
      publish('needs_input', 'claude_question_card');
      return;
    }
    if (isBusy) {
      previousBusy = true;
      busySeen = true;
      lastBusyAt = now;
      if (!startedAt) {
        startedAt = now;
        assistantBaseline = count;
        lastAssistantChangeAt = 0;
          }
      publish('working', 'stop_control_visible');
      return;
    }
    if (startedAt) {
      if (busySeen && now - lastBusyAt >= 1000) {
        done('stop_control_disappeared');
      } else if (!busySeen && lastAssistantChangeAt &&
                 now - lastAssistantChangeAt >= (isClaude ? 4500 : 2200) &&
                 now - startedAt >= (isClaude ? 5000 : 2400)) {
        done('assistant_dom_settled');
      } else if (!busySeen && now - startedAt > 90000) {
        // If we never observed a response, don't fabricate a completion.
        startedAt = 0;
        publish('idle', 'generation_unconfirmed_timeout');
      } else {
        publish('working', busySeen ? 'waiting_for_stop_to_clear' : 'awaiting_response');
        return;
      }
    }
    previousBusy = false;
    // Keep GREEN flashing for ALL completed responses, including ones ending in a question.
    // No automatic amber for reply wording; it is too easy to confuse with a normal finish.
    if (completedAt) publish('done', 'completed_waiting_for_keypress');
    else publish('idle', 'no_pending_response');
  }
  function queueScan() {
    if (scanTimer != null) return;
    scanTimer = setTimeout(() => { scanTimer = null; scan(); }, 180);
  }
  // Note changes to assistant DOM only; never inspect or transmit content.
  function onMutation(mutations) {
    if (startedAt && !demo) {
      const count = assistantCount();
      let touchedAssistant = count > assistantBaseline || count !== lastAssistantCount;
      if (!touchedAssistant) {
        touchedAssistant = mutations.some(m => {
          const el = m.target instanceof Element ? m.target : m.target.parentElement;
          if (!el) return false;
          if (el.closest(ASSISTANT_SELECTOR)) return true;
          // Claude's message markup changes often; treat any change outside the
          // composer as response activity. Only used when no stop/stream signal exists.
          return isClaude && !el.closest(COMPOSER_SELECTORS.join(',')) &&
            !el.closest('fieldset');
        });
      }
      if (touchedAssistant) lastAssistantChangeAt = Date.now();
      lastAssistantCount = count;
    }
    queueScan();
  }
  function isSendButton(btn) {
    if (!btn || !visible(btn)) return false;
    if (STOP_RE.test((btn.getAttribute('aria-label') || btn.getAttribute('title') || '').trim())) return false;
    if (SEND_SELECTORS.some(s => { try {return btn.matches(s);} catch (_) {return false;} })) {
      if (btn.matches('button[type="submit"]')) {
        const form = btn.closest('form');
        return !!form && !!form.querySelector(COMPOSER_SELECTORS.join(','));
      }
      return true;
    }
    const label = (btn.getAttribute('aria-label') || btn.getAttribute('title') || '').trim();
    const controls = btn.closest('form') || (isClaude ? (btn.closest('fieldset') || composerControls(composer())) : null);
    if (controls?.contains && !controls.contains(btn)) return false;
    return SEND_RE.test(label) && !!controls?.querySelector(COMPOSER_SELECTORS.join(','));
  }
  document.addEventListener('click', e => {
    // A real mouse click in ChatGPT/Claude may acknowledge a completed answer,
    // including when ANOTHER monitored AI tab is showing the green alert.
    // Do not send clicked elements, coordinates, or page text to the extension.
    if (!e.isTrusted) return;
    if (['done','needs_input'].includes(state) && Date.now() >= acknowledgeAfter) {
      acknowledge('ai_page_mouse_click');
    }
    chrome.runtime.sendMessage({type:'ACK_MOUSE'}).catch(()=>{});
    if (demo) return;
    const btn = e.target instanceof Element ? e.target.closest('button') : null;
    if (isSendButton(btn)) submit('send_button_click');
  }, true);
  document.addEventListener('submit', e => {
    if (!e.isTrusted || demo) return;
    if (e.target instanceof HTMLFormElement && e.target.querySelector(COMPOSER_SELECTORS.join(','))) submit('form_submit');
  }, true);
  document.addEventListener('keydown', e => {
    if (!e.isTrusted || e.repeat) return;
    // Chrome-only fallback (works when this AI tab has focus). Global physical
    // key detection uses a separate, optional Wooting analog FF53 HID grant.
    if (['done','needs_input'].includes(state) && Date.now() >= acknowledgeAfter) {
      acknowledge('ai_page_keypress');
      chrome.runtime.sendMessage({type:'ACK_KEY'}).catch(()=>{});
    }
    if (demo) return;
    if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.altKey || e.metaKey || e.isComposing) return;
    if (e.target instanceof Element && e.target.closest(COMPOSER_SELECTORS.join(','))) submit('enter_in_composer');
  }, true);
  document.addEventListener('visibilitychange', queueScan);
  window.addEventListener('focus', queueScan);
  new MutationObserver(onMutation).observe(document.documentElement, {
    childList: true, subtree: true, characterData: true, attributes: true,
    attributeFilter: ['aria-label', 'data-testid', 'disabled', 'aria-disabled', 'title', 'class', 'hidden', 'data-state', 'data-is-streaming', 'aria-busy'],
  });
  setInterval(scan, 1000); // Stable heartbeat to keep status current, also when tab is in background.
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg?.type === 'WOOTING_ACKNOWLEDGED') {
      if (['done','needs_input'].includes(state) || (demo && state==='done')) {
        // HID acknowledgement may arrive while ChatGPT is in another app/window.
        acknowledge('wooting_physical_key');
      }
      reply({ok:true});return false;
    }
    if (msg?.type === 'WOOTING_PAGE_DIAGNOSTIC') {
      reply({ok: true, currentState: state, ...snapshot()});
      return false;
    }
    if (msg?.type === 'WOOTING_PAGE_TEST') {
      demo = true;
      for (const t of demoTimer) clearTimeout(t);
      demoTimer = [];
      publish('working', 'demo', true);
      demoTimer.push(setTimeout(() => publish('done', 'demo', true), 3800));
      demoTimer.push(setTimeout(() => {
        // Trigger green until Wooting keypress, or a keypress/click in a monitored AI page.
        completedAt=Date.now();acknowledgeAfter=completedAt;
      }, 3800));
      reply({ok: true, info: 'Input-ack test: blue 3.8s → repeating green until keypress or page click → profile restore'});
      return false;
    }
  });
  lastAssistantCount = assistantCount();
  publish('idle', 'watcher_loaded', true);
  scan();
})();
