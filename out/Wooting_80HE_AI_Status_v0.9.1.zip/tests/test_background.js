const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const events={};const writes=[];const device={vendorId:0x31e3,productId:0x1402,productName:'Wooting 80HE',collections:[{usagePage:0xff55}],opened:false,
  async open(){this.opened=true;},async close(){this.opened=false;},
  async sendReport(id,data){writes.push({kind:'output',id,data:Array.from(data)});},
  async sendFeatureReport(id,data){writes.push({kind:'feature',id,data:Array.from(data)});}
};
const register=name=>({addListener:fn=>{events[name]=fn;}});
let stored={};
const chrome={storage:{local:{get:async()=>stored,set:async data=>{stored={...stored,...data};}}},
  action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},alarms:{create:()=>{},onAlarm:register('alarm')},
  tabs:{onRemoved:register('tabsRemoved'),onUpdated:register('tabsUpdated')},runtime:{onMessage:register('message'),onStartup:register('startup'),onInstalled:register('installed')}};
const hid={async getDevices(){return [device];},addEventListener:()=>{}};
const ctx={chrome,navigator:{hid},Date,Math,Number,Uint8Array,Map,URL,Error,Array,console,
  setInterval:()=>123,clearInterval:()=>{}};
vm.createContext(ctx);
const root=path.join(__dirname,'../extension');
ctx.importScripts=name=>vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),ctx);
const ask=(payload,sender={})=>new Promise(resolve=>events.message(payload,sender,resolve));
(async()=>{
  let r=await ask({type:'GET_STATUS'});assert.equal(r.connected,true);assert.equal(r.state,'idle');
  assert.equal(writes.length,0,'idle should not alter user profile');
  r=await ask({type:'TEST_RGB',state:'needs_input'});assert.equal(r.ok,true);
  assert.ok(writes.find(w=>w.kind==='feature'&&w.data[2]===0x21),'must init RGB');
  const output=writes.find(w=>w.kind==='output');assert.equal(output.id,5);assert.equal(output.data.length,2046);
  assert.equal(output.data[0],0xd1);assert.equal(output.data[1],0xda);assert.equal(output.data[2],0x0b);
  r=await ask({type:'CLEAR_TEST'});assert.equal(r.ok,true);
  assert.ok(writes.find(w=>w.kind==='feature'&&w.data[2]===0x20),'must restore RGB');
  r=await ask({type:'AI_STATUS',state:'working'},{tab:{id:3},url:'https://claude.ai/chat/123'});assert.equal(r.ok,true);
  r=await ask({type:'GET_STATUS'});assert.equal(r.state,'working');
  const n=writes.length;
  r=await ask({type:'AI_STATUS',state:'permission'},{tab:{id:4},url:'https://chatgpt.com/c/abc'});assert.equal(r.ok,true);
  r=await ask({type:'GET_STATUS'});assert.equal(r.state,'permission');
  r=await ask({type:'AI_STATUS',state:'needs_input'},{tab:{id:5},url:'https://evil.example'});assert.equal(r.ok,false);
  // A completed answer is latched without any profile reset between flashes.
  r=await ask({type:'AI_STATUS',state:'done'},{tab:{id:3},url:'https://claude.ai/chat/123'});
  r=await ask({type:'AI_STATUS',state:'idle'},{tab:{id:4},url:'https://chatgpt.com/c/abc'});
  assert.equal((await ask({type:'GET_STATUS'})).state,'done');
  const resetsBefore=writes.filter(w=>w.kind==='feature'&&w.data[2]===0x20).length;
  const outputsBefore=writes.filter(w=>w.kind==='output').length;
  await vm.runInContext('lastWriteAt = Date.now() - 800; update()',ctx);
  assert.ok(writes.filter(w=>w.kind==='output').length > outputsBefore,'should refresh live green RGB even if colour unchanged');
  assert.equal(writes.filter(w=>w.kind==='feature'&&w.data[2]===0x20).length,resetsBefore,'no reset while green flashes');
  assert.equal((await ask({type:'GET_STATUS'})).state,'done');
  // Legacy content scripts may still emit amber; never let it override green.
  r=await ask({type:'AI_STATUS',state:'needs_input'},{tab:{id:7},url:'https://chatgpt.com/c/old'});assert.equal(r.ok,true);
  r=await ask({type:'GET_STATUS',tabId:7});assert.equal(r.monitor.state,'done');
  r=await ask({type:'SAVE_SETTINGS',enabled:false,brightness:60,detectQuestions:true});assert.equal(r.enabled,false);assert.equal(r.detectQuestions,false);
  assert.equal(stored.detectQuestions,false,'retire prior enabled amber preference');
  assert.ok(writes.slice(n).find(w=>w.kind==='feature'&&w.data[2]===0x20),'disable restores RGB');
  console.log('PASS: Chrome SW WebHID connect, testing, reset, priority, origin filtering, disable');
})().catch(e=>{console.error(e);process.exitCode=1});
