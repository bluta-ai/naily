const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
let now=10000;let nextTimer=0;let timers=new Map();const messages=[];const listeners={};let pageListener;let observer;
function setT(fn,ms){const id=++nextTimer;timers.set(id,{at:now+ms,fn});return id;}
function clearT(id){timers.delete(id);}
function advance(ms){const until=now+ms;let loops=0;
  while(true){const arr=[...timers].filter(([k,t])=>t.at<=until).sort((a,b)=>a[1].at-b[1].at);
    if(!arr.length)break; if(++loops>5000)throw Error('timer loop');
    const [id,t]=arr[0];timers.delete(id);now=t.at;t.fn();
  }now=until;
}
class E {
  constructor(type){this.type=type;this.isConnected=true;this.disabled=false;this.parentElement=null;}
  matches(s){return s==='#composer-submit-button'&&this.type==='send' || s==='button[type="submit"]'&&this.type==='submit';}
  closest(s){if(s==='button'&&this.type==='send')return this;if(s.includes('form'))return this.type==='composer'?form:null;return this.type==='composer'?this:null;}
  getClientRects(){return [1]};getAttribute(name){return this.type==='send'&&name==='aria-label'?'Send message':null;}
}
const send=new E('send'),input=new E('composer'),stop=new E('stop'),assistant=new E('assistant');
assistant.innerText='A complete explanation, with no question.';
const form={querySelector:()=>input,querySelectorAll:()=>[],closest:()=>null};let stopVisible=false,assistantCount=0;
const document={documentElement:{},visibilityState:'visible',
  querySelector(s){return s==='#prompt-textarea'?input:s==='form[data-chatgpt-composer]'?form:null;},
  querySelectorAll(s){if(s==='[data-message-author-role="assistant"]')return assistantCount?Array(assistantCount).fill(assistant):[];
    if(s==='button[data-testid="stop-button"]')return stopVisible?[stop]:[];
    if(s==='#composer-submit-button')return [send];return [];},
  addEventListener(name,fn){listeners[name]=fn;}
};
const DateFake={now:()=>now};
let storageListener;
const ctx={document,Element:E,HTMLFormElement:class{},location:{hostname:'chatgpt.com'},
  getComputedStyle:()=>({visibility:'visible',display:'block'}),Date:DateFake,Math,Array,Number,
  globalThis:{},setTimeout:setT,clearTimeout:clearT,setInterval:(fn,ms)=>{const wrapper=()=>{fn();setT(wrapper,ms)};return setT(wrapper,ms);},
  MutationObserver:class{constructor(fn){this.fn=fn;observer=this;}observe(){}},
  window:{addEventListener(){}},
  chrome:{storage:{local:{get:async()=>({detectQuestions:false})},onChanged:{addListener(fn){storageListener=fn;}}},runtime:{sendMessage(msg){messages.push(msg);return Promise.resolve({ok:true});},onMessage:{addListener(fn){pageListener=fn;}}}},
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../extension/content.js'),'utf8'),ctx);
assert.ok(messages.some(x=>x.state==='idle'&&x.reason==='watcher_loaded'));
listeners.click({isTrusted:true,target:send});
assert.equal(messages.at(-1).state,'working');assert.equal(messages.at(-1).reason,'send_button_click');
stopVisible=true;observer.fn([{target:stop}]);advance(250);assert.equal(messages.at(-1).state,'working');
stopVisible=false;assistantCount=1;observer.fn([{target:assistant}]);advance(2150);
assert.equal(messages.at(-1).state,'done');assert.equal(messages.at(-1).reason,'stop_control_disappeared');
advance(1900);
assert.equal(messages.at(-1).state,'done', 'solid green remains for four seconds');
advance(2400);
assert.equal(messages.at(-1).state,'done', 'a normal answer remains green until keypress');
listeners.keydown({isTrusted:true,repeat:false,key:'A',target:input});
assert.equal(messages.at(-2).state,'idle','physical key in AI tab acknowledges completion');
assert.equal(messages.at(-1).type,'ACK_KEY','keydown should notify extension SW');
assert.equal(messages.some(x=>x.reason==='answer_waiting'),false);
let response;
pageListener({type:'WOOTING_PAGE_DIAGNOSTIC'},null,x=>response=x);
assert.equal(response.ok,true);assert.equal(response.watcherVersion,'0.9.1');
pageListener({type:'WOOTING_PAGE_TEST'},null,x=>response=x);
assert.equal(response.ok,true);
assert.equal(messages.at(-1).state,'working');
advance(4000);assert.equal(messages.at(-1).state,'done');
advance(3000);assert.equal(messages.at(-1).state,'done');
advance(1600);assert.equal(messages.at(-1).state,'done','demo stays green until key');
pageListener({type:'WOOTING_ACKNOWLEDGED'},null,x=>response=x);
assert.equal(response.ok,true);assert.equal(messages.at(-1).state,'idle');
// A page may never expose the stop control. Completing after the assistant DOM settles is a fallback.
listeners.click({isTrusted:true,target:send});
assert.equal(messages.at(-1).state,'working');
assistantCount=2;observer.fn([{target:assistant}]);advance(240);
advance(3400);
assert.equal(messages.at(-1).state,'done');
assert.equal(messages.at(-1).reason,'assistant_dom_settled');
advance(4400); assert.equal(messages.at(-1).state,'done');
pageListener({type:'WOOTING_ACKNOWLEDGED'},null,x=>response=x);
assert.equal(messages.at(-1).state,'idle');
// Regression: a direct question at the end of an answer must NEVER switch to amber.
// Simulate a user's old saved preference, which must be ignored in v0.8.3.
assistant.innerText='Would you like me to continue?';
listeners.click({isTrusted:true,target:send});
stopVisible=true;observer.fn([{target:stop}]);advance(230);
stopVisible=false;assistantCount=3;observer.fn([{target:assistant}]);advance(2300);
assert.equal(messages.at(-1).state,'done');
advance(4100);
assert.equal(messages.at(-1).state,'done','a response with a question must keep flashing green');
assert.equal(messages.some(x=>x.state==='needs_input'),false, 'no automatic amber messages ever');
// An ordinary trusted click on the AI page also acknowledges a question.
listeners.click({isTrusted:true,target:{closest:()=>null}});
assert.equal(messages.at(-2).state,'idle');
assert.equal(messages.at(-1).type,'ACK_MOUSE');
// Fresh finished answer: keyboard should still acknowledge.
listeners.click({isTrusted:true,target:send});
stopVisible=true;observer.fn([{target:stop}]);advance(230);
stopVisible=false;assistantCount=4;assistant.innerText='A complete explanation, with no question.';observer.fn([{target:assistant}]);advance(2300);
assert.equal(messages.at(-1).state,'done');
listeners.keydown({isTrusted:true,repeat:false,key:'x',target:input});
assert.equal(messages.at(-2).state,'idle');
assert.equal(messages.at(-1).type,'ACK_KEY');
// Real click dismisses the green demo too.
pageListener({type:'WOOTING_PAGE_TEST'},null,x=>response=x);
advance(4000);assert.equal(messages.at(-1).state,'done');
listeners.click({isTrusted:true,target:{closest:()=>null}});
assert.equal(messages.at(-2).state,'idle');
assert.equal(messages.at(-1).type,'ACK_MOUSE');
console.log('PASS: all completions (including questions) stay green; key/mouse acknowledgement, demo, fallback');
