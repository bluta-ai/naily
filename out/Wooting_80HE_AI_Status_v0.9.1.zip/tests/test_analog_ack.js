const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const events={}, writes=[], notified=[];
const makeDev=(page)=>({vendorId:0x31e3, productId:0x1402, productName:'Wooting 80HE',collections:[{usagePage:page}],opened:false,_inputs:[],
  async open(){this.opened=true;},async close(){this.opened=false;},
  async sendReport(id,data){writes.push({type:'out',id,data:Array.from(data)});},
  async sendFeatureReport(id,data){writes.push({type:'feat',id,data:Array.from(data)});},
  addEventListener(type,cb){if(type==='inputreport')this._inputs=[cb];},
  removeEventListener(type,cb){if(type==='inputreport')this._inputs=this._inputs.filter(x=>x!==cb);},
  sendKeys(bytes){const data=new DataView(Uint8Array.from(bytes).buffer);for(const fn of this._inputs)fn({data,device:this,reportId:0});}
});
const rgb=makeDev(0xff55),analog=makeDev(0xff53);
const register=name=>({addListener:fn=>events[name]=fn});
const chrome={storage:{local:{get:async()=>({}),set:async()=>{}}},
 action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},
 alarms:{create:()=>{},onAlarm:register('alarm')},
 tabs:{onRemoved:register('tabsRemoved'),onUpdated:register('tabsUpdated'),sendMessage:async(id,data)=>{notified.push({id,data});}},
 runtime:{onMessage:register('message'),onStartup:register('startup'),onInstalled:register('installed')}
};
const hid={getDevices:async()=>[rgb,analog],addEventListener:()=>{}};
const ctx={chrome,navigator:{hid},Date,Math,Number,Uint8Array,Map,URL,Error,Array,DataView,
  setInterval:()=>123,clearInterval:()=>{},console};
vm.createContext(ctx);
const root=path.join(__dirname,'../extension');
ctx.importScripts=name=>vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),ctx);
const ask=(payload,sender={})=>new Promise(resolve=>events.message(payload,sender,resolve));
const settle=()=>new Promise(r=>setTimeout(r,0));
(async()=>{
 let r=await ask({type:'GET_STATUS'});assert.equal(r.globalKeyConnected,true,'80HE analog interface should attach');
 assert.equal(r.connected,true,'80HE RGB interface should attach');
 // Detect an actual completed answer.
 r=await ask({type:'AI_STATUS',state:'done',reason:'complete'}, {tab:{id:11},url:'https://chatgpt.com/c/abc'});
 assert.equal(r.ok,true);
 r=await ask({type:'GET_STATUS'});assert.equal(r.state,'done');
 // V2 analog 4-byte records: matrixPos=1, scancodeLo=4, packed=0, analogHi=155.
 analog.sendKeys([1,4,0,155]);await settle();await settle();
 r=await ask({type:'GET_STATUS'});assert.equal(r.state,'idle','new physical key dismisses green');
 assert.ok(notified.some(n=>n.id===11 && n.data.type==='WOOTING_ACKNOWLEDGED'));
 assert.ok(writes.some(w=>w.type==='feat'&&w.data[2]===0x20),'must send Wooting RGB restore');
 // A new response must not be dismissed by repeated held-down input reports.
 r=await ask({type:'AI_STATUS',state:'done'},{tab:{id:11},url:'https://chatgpt.com/c/abc'});
 analog.sendKeys([1,4,0,155]);await settle();r=await ask({type:'GET_STATUS'});
 assert.equal(r.state,'done','held key must not dismiss a newly completed response');
 analog.sendKeys([0,0,0,0]); // release
 analog.sendKeys([1,4,0,155]);await settle();await settle();
 r=await ask({type:'GET_STATUS'});assert.equal(r.state,'idle','new downstroke dismisses next completion');
 // A hostile page must not trigger ACK_KEY.
 r=await ask({type:'AI_STATUS',state:'done'},{tab:{id:11},url:'https://chatgpt.com/c/abc'});
 const b=await ask({type:'ACK_KEY'},{tab:{id:15},url:'https://malicious.example/'});
 assert.equal(b.ok,false);r=await ask({type:'GET_STATUS'});assert.equal(r.state,'done');
 const a=await ask({type:'ACK_MOUSE'},{tab:{id:12},url:'https://claude.ai/new'});
 assert.equal(a.ok,true);r=await ask({type:'GET_STATUS'});assert.equal(r.state,'idle', 'click in another monitored tab dismisses green');
 assert.ok(notified.some(n=>n.id===11 && n.data.type==='WOOTING_ACKNOWLEDGED'));
 r=await ask({type:'AI_STATUS',state:'done'},{tab:{id:11},url:'https://chatgpt.com/c/abc'});
 const k=await ask({type:'ACK_KEY'},{tab:{id:11},url:'https://chatgpt.com/c/abc'});
 assert.equal(k.ok,true);r=await ask({type:'GET_STATUS'});assert.equal(r.state,'idle');
 console.log('PASS: 80HE analog global key and trusted AI-page mouse click → green ack → RGB restore, held-key safety, sender origin gate');
})().catch(e=>{console.error(e);process.exitCode=1});
