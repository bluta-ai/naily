'use strict';
const $=id=>document.getElementById(id);
const EXPECTED_VENDOR=0x31e3;
const lines=[];
function log(s){lines.push(`[${new Date().toLocaleTimeString()}] ${s}`);$('log').textContent=lines.slice(-90).join('\n');}
function result(s,level=''){$('result').textContent=s;$('result').className=`result ${level}`;}
function hex(n){return '0x'+(n>>>0).toString(16).padStart(4,'0').toUpperCase();}
function desc(d){return `${d.productName||'HID'} VID=${hex(d.vendorId)} PID=${hex(d.productId)} pages=${(d.collections||[]).map(c=>hex(c.usagePage)).join(',')}`;}
async function granted(){const devices=await navigator.hid.getDevices();log(`授權裝置 ${devices.length}: ${devices.map(desc).join(' | ')}`);return devices;}
async function info(){const r=await chrome.runtime.sendMessage({type:'GET_STATUS'});log(`Status connected=${r?.connected} analog=${r?.globalKeyConnected} analogFrames=${r?.analogFrames||0} analogError=${r?.analogError||'-'} name=${r?.deviceName} RGB=${r?.rgbActive} reportLength=${r?.reportLength||'?'} lastWrite=${r?.lastWriteAt||'-'} error=${r?.error||'-'}`);$('analogResult').textContent=r.globalKeyConnected?'Analog HID 已連接：其他 Windows 程式的 Wooting 按鍵亦可確認。':`未連接全局按鍵偵測：${r.analogError||'請按授權'}`;return r;}
async function pair(filters,diagnostic=false){
  const btn=$(diagnostic?'unfiltered':'pair');btn.disabled=true;
  try{
    if(!navigator.hid)throw new Error('WebHID 不可用：需要桌面版 Chrome 117 或更新版本。');
    log(`requestDevice, userActivation=${navigator.userActivation?.isActive??'unknown'}`);
    const ds=await navigator.hid.requestDevice({filters});
    log(`選擇 ${ds.length} 個 HID。${ds.map(desc).join(' | ')}`);
    if(!ds.length){result('沒有選擇裝置。','warn');return;}
    if(!ds.some(d=>d.vendorId===EXPECTED_VENDOR)){result('不是 Wooting 鍵盤，未嘗試連接。','warn');return;}
    const r=await chrome.runtime.sendMessage({type:'CONNECT_HID'});
    await info();
    result(r.connected?`已連上 ${r.deviceName}。現在按「測試全鍵盤橙色閃爍」。`:`未能開啟 80HE 的 RGB 通訊介面：${r.error||'請檢查診斷紀錄'}`,r.connected?'ok':'bad');
  }catch(e){log(`${e.name}: ${e.message}`);result(`授權失敗：${e.message}`,'bad');}
  finally{btn.disabled=false;}
}
$('pair').addEventListener('click',async()=>{
  try {const ds=await granted();if(ds.some(d=>d.vendorId===EXPECTED_VENDOR&&(d.productId&0xfff0)===0x1400)) {
    const r=await chrome.runtime.sendMessage({type:'CONNECT_HID'});
    result(r.connected?`已連上 ${r.deviceName}，可以測試 RGB。`:r.error,r.connected?'ok':'warn');await info();
  } else await pair([{vendorId:EXPECTED_VENDOR}]);}
  catch(e){result(e.message,'bad');}
});
$('unfiltered').addEventListener('click',()=>pair([],true));
$('pairAnalog').addEventListener('click',async()=>{
  const b=$('pairAnalog'); b.disabled=true;
  try {
    // REQUEST DEVICE MUST RUN FROM AN EXPLICIT USER CLICK, in this extension page.
    // A separate vendor-specific interface with no access to standard keyboard reports.
    const ds=await navigator.hid.requestDevice({filters:[{vendorId:EXPECTED_VENDOR,usagePage:0xff53},{vendorId:EXPECTED_VENDOR,usagePage:0xff54}]});
    log(`Analog HID permission selected: ${ds.map(desc).join(' | ')||'cancelled'}`);
    if(!ds.length){$('analogResult').textContent='未選擇裝置。';return;}
    const r=await chrome.runtime.sendMessage({type:'CONNECT_ANALOG'});
    $('analogResult').textContent=r.globalKeyConnected?'成功！現在只要按 Wooting 實體鍵，就可停止正在閃爍的綠燈。':`尚未連接：${r.analogError||'請查看診斷紀錄'}`;
    await info();
  } catch(e) {log(`Analog: ${e.name}: ${e.message}`);$('analogResult').textContent=`授權出錯：${e.message}`;}
  finally {b.disabled=false;}
});
$('granted').addEventListener('click',async()=>{try {await granted();await info();result('檢查完成，請看診斷紀錄。','ok');}catch(e){result(e.message,'bad');}});
$('test').addEventListener('click',async()=>{
  try{const r=await chrome.runtime.sendMessage({type:'TEST_RGB',state:'needs_input'});await info();result(r.ok?'RGB 指令已傳送，應該可看到鍵盤橙色閃爍（9 秒）。若沒有亮燈，複製診斷紀錄。':`RGB 測試失敗：${r.error||'未知錯誤'}`,r.ok?'ok':'bad');}
  catch(e){log(e.message);result(e.message,'bad');}
});
$('stop').addEventListener('click',async()=>{const r=await chrome.runtime.sendMessage({type:'CLEAR_TEST'});await info();result(r.error||'已發送恢復原本 RGB 指令。',r.error?'warn':'ok');});
$('copy').addEventListener('click',async()=>{try {await info();await navigator.clipboard.writeText(lines.join('\n'));result('診斷紀錄已複製。','ok');}catch(e){result(e.message,'bad');}});
$('clear').addEventListener('click',()=>{lines.length=0;$('log').textContent='';result('紀錄已清除。')});
(async()=>{
  $('environment').textContent=`WebHID ${navigator.hid?'支援 ✓':'不支援 ✕'} · ${navigator.userAgent.match(/Chrome\/\d+/)?.[0]||'Chrome ?'}`;
  try{await granted();await info();if(location.hash==='#analog')$('analogSection').scrollIntoView({block:'start'});}catch(e){log(e.message);}
})();
