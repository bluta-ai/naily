/*
 * Wooting 80HE live RGB protocol, ported from the public Wooting RGB SDK:
 * https://github.com/WootingKb/wooting-rgb-sdk (MPL-2.0)
 * Copyright 2018 Wooting Technologies B.V. (upstream protocol source)
 * This port sends VOLATILE per-key colors; it NEVER writes an onboard profile.
 * HID report ID is passed separately to WebHID.
 */
'use strict';
const WOOTING_VENDOR = 0x31E3;
const WOOTING_CONFIG_PAGE = 0xFF55;
const WOOTING_RGB_REPORT_ID = 5;
const WOOTING_FEATURE_REPORT_ID = 1;
const WOOTING_RGB_ROWS = 6;
const WOOTING_RGB_COLS = 21;
const WOOTING_80HE_COLS = 17;
const WOOTING_V3_REPORT_LENGTH = 2046; // HID report payload bytes (ID excluded)
const WOOTING_RGB_CMD = 0x0B;
const WOOTING_RGB_INIT = 0x21;
const WOOTING_RGB_RESET = 0x20;
const VALID_STATES = ['idle', 'working', 'done', 'needs_input', 'permission'];

function is80he(d) {
  const model = d.productId & 0xFFF0;
  return d.vendorId === WOOTING_VENDOR && (model === 0x1400 || model === 0x1410);
}
function hasConfigCollection(collections) {
  return (collections || []).some(c => c.usagePage === WOOTING_CONFIG_PAGE || hasConfigCollection(c.children));
}
function isConfigDevice(d) { return is80he(d) && hasConfigCollection(d.collections); }
function nestedCollections(collections) {
  return (collections || []).flatMap(c => [c, ...nestedCollections(c.children)]);
}
function findRgbReportLength(device) {
  for (const c of nestedCollections(device.collections)) {
    for (const report of c.outputReports || []) {
      if (report.reportId !== WOOTING_RGB_REPORT_ID) continue;
      const bits = (report.items || []).reduce((sum, item) => sum + Number(item.reportSize || 0) * Number(item.reportCount || 0), 0);
      if (bits >= (3 + WOOTING_RGB_ROWS * WOOTING_RGB_COLS * 2) * 8 && bits % 8 === 0)
        return bits / 8;
    }
  }
  return WOOTING_V3_REPORT_LENGTH;
}
function encodeRgb565(r, g, b) {
  return ((r & 0xf8) << 8) | ((g & 0xfc) << 3) | (b >> 3);
}
function clamp8(v) { return Math.max(0, Math.min(255, Math.round(v))); }
function makeRgbReport(r, g, b, length = WOOTING_V3_REPORT_LENGTH) {
  if (length < 3 + WOOTING_RGB_ROWS * WOOTING_RGB_COLS * 2) throw new Error('Wooting RGB report too short');
  const bytes = new Uint8Array(length);
  bytes.set([0xD1, 0xDA, WOOTING_RGB_CMD], 0);
  const color = encodeRgb565(clamp8(r), clamp8(g), clamp8(b));
  // Matches uint16_t rgb_buffer[6][21], little-endian, from Wooting official SDK.
  for (let row = 0; row < WOOTING_RGB_ROWS; row++) {
    for (let col = 0; col < WOOTING_80HE_COLS; col++) {
      const offset = 3 + 2 * (row * WOOTING_RGB_COLS + col);
      bytes[offset] = color & 0xff;
      bytes[offset + 1] = color >> 8;
    }
  }
  return bytes;
}
function makeFeatureCommand(command) {
  // Official SDK: hid_send_feature_report([0x01, 0xD1, 0xDA, command, 0,0,0,0])
  // WebHID: sendFeatureReport(1, remaining seven bytes).
  if (![WOOTING_RGB_INIT, WOOTING_RGB_RESET].includes(command)) throw new Error('Unsupported feature command');
  return Uint8Array.from([0xD1, 0xDA, command, 0, 0, 0, 0]);
}
function scaledRgb(color, brightness) {
  const factor = Math.max(0, Math.min(1, brightness));
  return color.map(c => clamp8(c * factor));
}
function frameForState(state, now, intensity = 0.60) {
  if (state === 'idle') return null;
  // Don't exceed 2 flashes per second; working is a gradual pulse.
  if (state === 'working') {
    const breath = 0.20 + 0.80 * ((1 + Math.sin(now * Math.PI * 2 / 2400 - Math.PI/2)) / 2);
    return scaledRgb([34, 145, 255], intensity * breath);
  }
  if (state === 'done') {
    // Continuous green-only flashing until acknowledgement. The dim phase is
    // still GREEN (not Wootility's original profile or a profile reset).
    // This creates an unmistakable bright/dim green blink with no RGB reset
    // between flashes. 600ms bright + 400ms dim, repeated indefinitely.
    const bright = now % 1000 < 600;
    return scaledRgb([18, 255, 95], intensity * (bright ? 1 : 0.08));
  }
  if (state === 'needs_input') {
    const on = now % 1100 < 550;
    return scaledRgb([255, 165, 10], on ? intensity : 0.02);
  }
  if (state === 'permission') {
    const period = now % 1300;
    const on = period < 170 || (period >= 320 && period < 490);
    return scaledRgb([255, 28, 42], on ? intensity : 0.02);
  }
  return null;
}
function priorityState(states) {
  for (const s of ['permission', 'needs_input', 'working', 'done']) {
    if (states.includes(s)) return s;
  }
  return 'idle';
}

// Wooting 80HE analog V2 reports use vendor usage page 0xFF53.
// These are separate from the RGB config HID interface (0xFF55), requiring explicit permission.
// We examine only whether ANY key is physically pressed. We never store key identities or typed text.
const WOOTING_ANALOG_V2_PAGE = 0xFF53;
const WOOTING_ANALOG_V1_PAGE = 0xFF54;
function isAnalogDevice(d) {
  return is80he(d) && nestedCollections(d.collections).some(c =>
    c.usagePage === WOOTING_ANALOG_V2_PAGE || c.usagePage === WOOTING_ANALOG_V1_PAGE);
}
function isAnalogV2(d) {return nestedCollections(d.collections).some(c=>c.usagePage===WOOTING_ANALOG_V2_PAGE);}
function analogReportHasPressedKey(bytes, v2=true) {
  // WebHID inputreport.data omits report-ID byte.
  // Newer 80HE FF53 reports: [matrix_pos, scancode_low, packed, analog_hi] per key.
  // The analog value is ((analog_hi << 2) | (packed >> 6)); ignore below 2% travel.
  if (!bytes || !bytes.byteLength) return false;
  const view = bytes instanceof DataView ? bytes : new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (v2) {
    for (let i=0; i+3<view.byteLength; i+=4) {
      const code=view.getUint8(i+1), packed=view.getUint8(i+2), hi=view.getUint8(i+3);
      if (code !== 0 && ((hi << 2) | (packed >> 6)) >= 20) return true;
    }
  } else {
    // Legacy analog V1 format: [scancode_hi, scancode_lo, analog_u8].
    for (let i=0; i+2<view.byteLength; i+=3) {
      const code=(view.getUint8(i)<<8)|view.getUint8(i+1);
      if (code!==0 && view.getUint8(i+2)>=5) return true;
    }
  }
  return false;
}
