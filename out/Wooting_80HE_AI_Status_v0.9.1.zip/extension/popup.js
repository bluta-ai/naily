'use strict';
const el=id=>document.getElementById(id);
const LABELS={idle:'閒置',working:'AI 正在處理',done:'回答完成 · 等待按鍵／點擊',needs_input:'等待你輸入／閱讀',permission:'需要批准或確認'};
const COLORS={idle:'#7386a6',working:'#4b95f0',done:'#3cb887',needs_input:'#eab04b',permission:'#ee6679'};
const tell=payload=>chrome.runtime.sendMessage(payload);
const isAiUrl=url=>/^https:\/\/(chatgpt\.com|chat\.openai\.com|claude\.ai)(\/|$)/.test(url||'');
let lastDiag={};
function error(m){const t=el('error');t.hidden=!m;t.textContent=m||'';}
function paint(s){
  if(!s) return;
  el('connection').textContent=s.connected?'已連接 Wooting 80HE':'尚未連接';
  el('detail').textContent=s.connected?s.deviceName:'請按連接／診斷鍵盤';
  el('connDot').style.background=s.connected?'#50d6a0':'#eeb350';
  el('mode').textContent=LABELS[s.state]||'閒置';
  el('analogStatus').textContent=s.globalKeyConnected?'已啟用全局任意鍵確認':'支援 AI 網頁內按鍵或點擊（未授權全局按鍵）';
  el('analogDot').style.background=s.globalKeyConnected?'#50d6a0':'#eeb350';
  el('modeDot').style.background=COLORS[s.state]||COLORS.idle;
  el('tabCount').textContent=`${s.activeTabs||0} 個活躍 AI 工作階段`;
  el('enabled').checked=s.enabled!==false;
  el('brightness').value=s.brightness||60;
  el('brightnessValue').textContent=`${s.brightness||60}%`;
  error(s.error||'');
}
async function activeTab(){return (await chrome.tabs.query({active:true,currentWindow:true}))[0]||null;}
async function pageDiagnostics(){
  const tab=await activeTab();
  if(!tab || !isAiUrl(tab.url)){
    el('pageState').textContent='目前不是 AI 分頁';el('pageDetails').textContent='請在 ChatGPT 或 Claude 的分頁打開此擴充功能。';
    el('pageAge').textContent='';el('pageDot').style.background='#aeb9cc';
    el('diagnostics').textContent='未選取 ChatGPT / Claude 分頁';
    lastDiag={message:'No active supported AI tab'};return;
  }
  const status=await tell({type:'GET_STATUS',tabId:tab.id});
  let page;
  try{page=await chrome.tabs.sendMessage(tab.id,{type:'WOOTING_PAGE_DIAGNOSTIC'});}
  catch(e){page={ok:false,error:e.message};}
  const monitor=status.monitor;
  const alive=!!page?.ok;
  el('pageDot').style.background=alive?'#50d6a0':'#eeb350';
  el('pageState').textContent=alive?'頁面監測器已啟動':'網頁監測器未載入';
  el('pageAge').textContent=monitor?`${Math.floor((Date.now()-monitor.at)/1000)} 秒前更新`:'沒有狀態紀錄';
  el('pageDetails').textContent=alive?
    `偵測：${LABELS[monitor?.state]||'未收到狀態'} · ${monitor?.reason||'等待事件'} · 發送按鈕 ${page.sendControl?'✓':'—'} · 停止／串流 ${page.busyControl?'✓':'—'}${page.site==='Claude' ? ' · Claude streaming '+String(page.claudeStreaming) : ''}`:
    '請 Ctrl+R 重新整理這個 AI 分頁，再打開擴充功能。';
  lastDiag={site:new URL(tab.url).hostname,connected:status.connected,rgbEnabled:status.enabled,
    globalState:status.state,hidError:status.error||'',
    globalKeyConnected:status.globalKeyConnected, analogFrames:status.analogFrames, analogError:status.analogError,
    page:page,monitor:monitor?{state:monitor.state,reason:monitor.reason,
      ageSeconds:Math.floor((Date.now()-monitor.at)/1000),telemetry:monitor.telemetry}:null};
  // No message text or typing is included in telemetry.
  el('diagnostics').textContent=JSON.stringify(lastDiag,null,2).slice(0,1600);
}
async function refresh(){try{paint(await tell({type:'GET_STATUS'}));await pageDiagnostics();}
  catch(e){error(`無法取得狀態：${e.message}`);}}
el('analogConnect').addEventListener('click',async()=>{
  await chrome.tabs.create({url:chrome.runtime.getURL('connect.html')+'#analog'});
});
el('connect').addEventListener('click',async()=>{
  try {await chrome.tabs.create({url:chrome.runtime.getURL('connect.html')});}
  catch(e){error(`無法開啟授權頁：${e.message}`);}
});
document.querySelectorAll('[data-test]').forEach(b=>b.addEventListener('click',async()=>{
  try {const r=await tell({type:'TEST_RGB',state:b.dataset.test});paint(r);if(!r.ok)error(r.error||'測試未開始，請檢查鍵盤連線。');}
  catch(e){error(`測試失敗：${e.message}`);}
}));
el('clear').addEventListener('click',async()=>{try{paint(await tell({type:'CLEAR_TEST'}));}catch(e){error(e.message);}});
el('brightness').addEventListener('input',()=>{el('brightnessValue').textContent=`${el('brightness').value}%`;});
el('save').addEventListener('click',async()=>{
  try {paint(await tell({type:'SAVE_SETTINGS',enabled:el('enabled').checked,brightness:Number(el('brightness').value)}));}
  catch(e){error(e.message);}
});
el('pageTest').addEventListener('click',async()=>{
  const tab=await activeTab();
  if(!tab || !isAiUrl(tab.url)){error('請先切換至 chatgpt.com 或 claude.ai 分頁，再開啟擴充功能。');return;}
  try{
    const r=await chrome.tabs.sendMessage(tab.id,{type:'WOOTING_PAGE_TEST'});
    if(!r?.ok)throw new Error(r?.error||'測試未啟動');
    el('pageDetails').textContent='測試中：藍色 3.8 秒 → 綠色不停閃爍；按 Wooting 實體鍵，或點擊 ChatGPT／Claude 頁面，即可還原。';
    error('');
  }catch(e){error(`頁面測試失敗：${e.message}。請 Ctrl+R 重新整理 ChatGPT 或 Claude。`);}
});
el('copyStatus').addEventListener('click',async()=>{
  try {await pageDiagnostics();await navigator.clipboard.writeText(JSON.stringify(lastDiag,null,2));
    el('pageDetails').textContent='診斷紀錄已複製（不包括對話內容）。';}
  catch(e){error('複製失敗：'+e.message);}
});
refresh();
const poll=setInterval(refresh,3500);
window.addEventListener('pagehide',()=>clearInterval(poll));
