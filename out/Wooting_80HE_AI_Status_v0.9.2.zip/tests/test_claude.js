'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
let now=10000,id=0,observer,pageListener;
const timers=new Map(), listeners={}, messages=[];
function schedule(fn,ms){const key=++id;timers.set(key,{at:now+ms,fn});return key;}
function clear(key){timers.delete(key);}
function advance(ms){const end=now+ms;let loops=0;while(true){const due=[...timers].filter(([,x])=>x.at<=end).sort((a,b)=>a[1].at-b[1].at);if(!due.length)break;if(++loops>10000)throw Error('timer loop');const [k,v]=due[0];timers.delete(k);now=v.at;v.fn();}now=end;}
const location={hostname:'claude.ai',href:'https://claude.ai/chat/first'};
class E {
  constructor(type){this.type=type;this.disabled=false;this.isConnected=true;this.parentElement=this;}
  getClientRects(){return [1];}
  getAttribute(name){
    if (this.type==='response' && name==='data-is-streaming')return stream ? 'true':'false';
    if (this.type==='send' && name==='aria-label')return 'Send message';
    return null;
  }
  matches(selector){return this.type==='send'&&selector.includes('send');}
  closest(selector){
    if(selector==='button')return this.type==='send'?this:null;
    if(this.type==='composer' && selector.includes('ProseMirror'))return this;
    if(selector.includes('form'))return null;
    if(selector==='fieldset')return fieldset;
    if(selector.includes('.font-claude-message'))return this.type==='response'?this:null;
    return null;
  }
  querySelector(selector){return this.type==='fieldset'&&selector.includes('contenteditable')?input:null;}
  querySelectorAll(selector){return this.type==='fieldset'&&selector==='button'?[send]:[];}
}
const input=new E('composer'),send=new E('send'),response=new E('response'),fieldset=new E('fieldset');
let streamPresent=true,stream=false,assist=0,stopVisible=false;
const document={documentElement:{},addEventListener(name,fn){listeners[name]=fn;},
  querySelector(selector){
    if (selector==='div.ProseMirror[contenteditable="true"]')return input;
    return null;
  },
  querySelectorAll(selector){
    if (selector==='[data-is-streaming]')return streamPresent?[response]:[];
    if (selector.includes('.font-claude-message'))return assist?[response]:[];
    if (selector==='button[aria-label="Stop response"]')return stopVisible?[new E('stop')]:[];
    if (selector.includes('send'))return [send];
    return [];
  }
};
const ctx={Element:E,HTMLFormElement:class{},location,document,Math,Array,Number,Date:{now:()=>now},globalThis:{},
  getComputedStyle:()=>({visibility:'visible',display:'block'}),
  setTimeout:schedule,clearTimeout:clear,setInterval:(fn,ms)=>{const rep=()=>{fn();schedule(rep,ms);};return schedule(rep,ms);},
  MutationObserver:class{constructor(fn){this.fn=fn;observer=this;}observe(){}},
  window:{addEventListener(){}},
  chrome:{runtime:{sendMessage(msg){messages.push(msg);return Promise.resolve({ok:true});},onMessage:{addListener(fn){pageListener=fn;}}}}
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../extension/content.js'),'utf8'),ctx);
function diag(){let result;pageListener({type:'WOOTING_PAGE_DIAGNOSTIC'},null,x=>result=x);return result;}
assert.equal(diag().site,'Claude');
assert.equal(diag().watcherVersion,'0.9.2');
assert.equal(diag().claudeStreaming,false);
assert.ok(diag().composerPresent);
// Claude's send button is in a fieldset, not a form. Detect it and the streaming attribute.
listeners.click({isTrusted:true,target:send});
assert.equal(messages.at(-1).state,'working');
assert.equal(messages.at(-1).reason,'send_button_click');
stream=true;assist=1;observer.fn([{target:response}]);advance(350);
assert.equal(messages.at(-1).state,'working');
assert.equal(diag().claudeStreaming,true);
assert.equal(diag().claudeStreamingSeen,true);
assert.equal(diag().lastDetectedSignal,'claude_stream_attribute');
stream=false;observer.fn([{target:response}]);advance(1900);
assert.equal(messages.at(-1).state,'done','streaming true->false produces completed green alert');
// Unlike the previous version, never turn this into amber.
advance(8000);
assert.equal(messages.at(-1).state,'done');
assert.equal(messages.some(m=>m.state==='needs_input'),false);
listeners.click({isTrusted:true,target:{closest:()=>null}});
assert.equal(messages.at(-2).state,'idle');assert.equal(messages.at(-1).type,'ACK_MOUSE');
// A request without a stop control or streaming attribute should complete from
// assistant content DOM settlement, but wait longer than ChatGPT to avoid short tool pauses.
streamPresent=false;assist=1;
listeners.keydown({isTrusted:true,repeat:false,key:'Enter',shiftKey:false,ctrlKey:false,altKey:false,metaKey:false,isComposing:false,target:input});
assert.equal(messages.at(-1).state,'working');
assist=2;observer.fn([{target:response}]);advance(210);
advance(3300);assert.equal(messages.at(-1).state,'working','avoid false Claude completion mid-stream');
advance(2400);assert.equal(messages.at(-1).state,'done','Claude DOM stabilization fallback');
// SPA route change clears the prior chat completion indicator.
location.href='https://claude.ai/chat/second';observer.fn([{target:response}]);advance(250);
assert.equal(messages.at(-1).state,'idle');
assert.equal(messages.some(m=>m.reason==='conversation_changed'),true);
// Claude can begin streaming automatically when Send click isn't observable.
streamPresent=true;stream=true;observer.fn([{target:response}]);advance(250);
assert.equal(messages.at(-1).state,'working');
stream=false;observer.fn([{target:response}]);advance(1600);
assert.equal(messages.at(-1).state,'done');
// claude.ai/new -> /chat/<id> happens right after the first send; keep tracking that request.
listeners.click({isTrusted:true,target:{closest:()=>null}});
streamPresent=false;assist=2;
listeners.click({isTrusted:true,target:send});
assert.equal(messages.at(-1).state,'working');
location.href='https://claude.ai/chat/third';observer.fn([{target:response}]);advance(250);
assert.equal(messages.at(-1).state,'working','URL change during an in-flight request must not reset it');
assert.equal(messages.at(-1).reason,'conversation_url_updated');
assist=3;observer.fn([{target:response}]);advance(6000);
assert.equal(messages.at(-1).state,'done','request survives the /new -> /chat URL change');
console.log('PASS: Claude send, streaming true/false, no-stop fallback, route change, spontaneous streaming, new-chat URL change');
